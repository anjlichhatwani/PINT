/**
 * Created by Dionny on 11/27/2015.
 */
angular.module('statelessApp').factory('Logger', function () {
    return {
        log: function (data) {
            //console.log(data);
        }
    };
});