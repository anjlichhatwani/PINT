package com.pint.BusinessLogic.Utilities;

public class Constants {
    public static final String BLOODDRIVE_TABLE_NAME = "blooddrive";
    public static final String DONOR_TABLE_NAME = "donor";
    public static final String EMPLOYEE_TABLE_NAME = "employee";
    public static final String NOTIFICATION_TABLE_NAME = "notification";
    public static final String HOSPITAL_TABLE_NAME = "hospital";
    public static final String USERNOTIFICATION_TABLE_NAME = "user_notification";
}
