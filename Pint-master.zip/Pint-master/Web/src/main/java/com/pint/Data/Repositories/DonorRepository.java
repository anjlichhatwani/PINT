package com.pint.Data.Repositories;

import com.pint.Data.Models.Donor;
import org.springframework.data.repository.CrudRepository;

public interface DonorRepository extends CrudRepository<Donor, Long> {

}
