package com.pint.Data.Repositories;

import com.pint.Data.Models.BloodDrive;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by Dionny on 11/24/2015.
 */
public interface BloodDriveRepository extends CrudRepository<BloodDrive, Long> {

}
