package com.pint.Data.Repositories;

public class JDBCDriver {

    /**
     * Reads data from the database
     *
     * @param queryString The query describing the read
     */
    public void query(String queryString) {
        // TODO Auto-generated method
    }

    /**
     * Udates data in the database
     *
     * @param updateString The query describing the update
     */
    public void update(String updateString) {
        // TODO Auto-generated method
    }

    /**
     * Removes data from the database
     *
     * @param queryString The query describing the removal
     */
    public void delete(String queryString) {
        // TODO Auto-generated method
    }

    /**
     * Writes data into the database
     *
     * @param insertString The query describing the write
     */
    public void insert(String insertString) {
        // TODO Auto-generated method
    }

    /**
     * Connects to the database
     *
     * @param connectionString The database connect request
     */
    public void connect(String connectionString) {
        // TODO Auto-generated method
    }
}
