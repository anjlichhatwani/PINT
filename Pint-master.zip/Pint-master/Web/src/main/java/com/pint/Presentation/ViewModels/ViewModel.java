package com.pint.Presentation.ViewModels;

/**
 * Created by Dionny on 11/26/2015.
 */
public class ViewModel {
}
