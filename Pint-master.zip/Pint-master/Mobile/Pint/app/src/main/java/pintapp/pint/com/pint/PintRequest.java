package pintapp.pint.com.pint;

import org.json.JSONObject;

/**
 * Created by gregoryjean-baptiste on 11/27/15.
 */
public interface PintRequest {
    public void pintResponse(JSONObject jsonObject);
}
