package pintapp.pint.com.pint;

/**
 * Created by gregoryjean-baptiste on 11/27/15.
 */
public class PintType {
    public static final int BLOODDRIVE = 0;
    public static final int USERNOTIFICATION = 1;
    public static final int BLOODDRIVEUSERNOTIFICATION = 2;
}
