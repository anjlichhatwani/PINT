package ECore;

public class EJavaObject extends Object
{
	
}