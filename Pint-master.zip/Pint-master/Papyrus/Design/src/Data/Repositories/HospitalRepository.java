package Data.Repositories;

import java.util.List;
import Data.Models.Hospital;

public class HospitalRepository extends Repository {

	/**
	 * Fetches a list of all hospitals
	 * @return A list of all hospitals in the application
	 */
	public List<Hospital> getHospitals() { 
		// TODO Auto-generated method
		return null;
	 } 

}
