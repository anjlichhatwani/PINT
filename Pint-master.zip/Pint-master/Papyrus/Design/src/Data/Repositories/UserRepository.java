package Data.Repositories;

import Data.Models.Employee;
import java.util.List;

public class UserRepository extends Repository {

	/**
	 * Saves a new employee
	 * @param employee The object containing information about the new employee
	 */
	public void createEmployee(Employee employee) { 
		// TODO Auto-generated method
	 }

	/**
	 * Fetches a list of all nurses at a hospital
	 * @param hospital_id The id of the relevant hospital
	 * @return A list of employees
	 */
	public List<Employee> getAllNurses(int hospital_id) { 
		// TODO Auto-generated method
		return null;
	 } 

}
