package Client.Mobile;

public class MobileScreen { 

}
