package Client.Mobile;

public class MobileLoginScreen extends MobileScreen {

	/**
	 * 
	 */
	public void setValues() { 
		// TODO Auto-generated method
	 }

	/**
	 * Initiates the authentication process for the user
	 */
	public void clickLogin() { 
		// TODO Auto-generated method
	 }

	/**
	 * Sets the username and password entered through the interface
	 * @param username The user name associated with a Pint account
	 * @param password The password for the account associated with the user name
	 */
	public void setValues(String username, String password) { 
		// TODO Auto-generated method
	 } 

}
