package Client.Web;

public class NurseDashboard extends WebScreen {

	/**
	 * Adds donor information to the associated blood drive
	 */
	public void addDonor() { 
		// TODO Auto-generated method
	 }

	/**
	 * Displays the form used to add a donor to the associated blood drive
	 */
	public void displayAddDonorPopup() { 
		// TODO Auto-generated method
	 }

	/**
	 * Sets the value of the email address of the current donor.
	 * @param emailAddress 
	 */
	public void enterEmail(String emailAddress) { 
		// TODO Auto-generated method
	 }

	/**
	 * Submits form information for further processing
	 */
	public void submit() { 
		// TODO Auto-generated method
	 }

	/**
	 * Displays a confirmation for the user before allowing donor information to be submitted
	 */
	public void displayConfirmation() { 
		// TODO Auto-generated method
	 }

	/**
	 * Accepts user confirmation for submitting donor information.
	 */
	public void confirm() { 
		// TODO Auto-generated method
	 }

	/**
	 * Displays a list of blood drives assigned to the current nurse
	 */
	public void viewBloodDrives() { 
		// TODO Auto-generated method
	 } 

}
