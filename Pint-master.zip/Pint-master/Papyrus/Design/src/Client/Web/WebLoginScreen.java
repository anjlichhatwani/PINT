package Client.Web;

public class WebLoginScreen extends WebScreen { 

}
