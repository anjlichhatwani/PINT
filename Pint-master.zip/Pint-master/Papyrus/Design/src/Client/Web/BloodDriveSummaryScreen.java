package Client.Web;

public class BloodDriveSummaryScreen extends WebScreen { 

}
