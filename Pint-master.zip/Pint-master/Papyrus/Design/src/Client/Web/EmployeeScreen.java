package Client.Web;

public class EmployeeScreen extends WebScreen { 

}
