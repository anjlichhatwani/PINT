package Client.Web;

public class BloodDriveDetailScreen extends WebScreen { 

}
