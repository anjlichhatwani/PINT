package Client.Web;

public class WebScreen { 

}
