package Presentation.ViewModels;

public class ViewModel { 

}
