package Presentation.ViewStrategies;

import ECore.EJavaObject;

public class BloodDriveDetailStrategy extends ViewModelStrategy {

	/**
	 * Creates a BloodDriveDetail View Model
	 * @param model The data that will populate the model
	 */
	public void createViewModel(EJavaObject model) { 
		// TODO Auto-generated method
	 } 

}
