package Presentation.ViewStrategies;

import ECore.EJavaObject;

public class BloodDriveSummaryStrategy extends ViewModelStrategy {

	/**
	 * Creates a BloodDriveSummary View Model
	 * @param model The data that will populate the model
	 */
	public void createViewModel(EJavaObject model) { 
		// TODO Auto-generated method
	 } 

}
