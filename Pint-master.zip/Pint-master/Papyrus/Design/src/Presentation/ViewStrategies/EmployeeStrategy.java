package Presentation.ViewStrategies;

import ECore.EJavaObject;

public class EmployeeStrategy extends ViewModelStrategy {

	/**
	 * Creates a Employee View Model
	 * @param model The data that will populate the model
	 */
	public void createViewModel(EJavaObject model) { 
		// TODO Auto-generated method
	 } 

}
