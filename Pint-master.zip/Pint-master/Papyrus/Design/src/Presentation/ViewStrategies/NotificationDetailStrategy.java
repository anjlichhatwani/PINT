package Presentation.ViewStrategies;

import ECore.EJavaObject;

public class NotificationDetailStrategy extends ViewModelStrategy {

	/**
	 * Creates a NotificationDetail View Model
	 * @param model The data that will populate the model
	 */
	public void createViewModel(EJavaObject model) { 
		// TODO Auto-generated method
	 } 

}
