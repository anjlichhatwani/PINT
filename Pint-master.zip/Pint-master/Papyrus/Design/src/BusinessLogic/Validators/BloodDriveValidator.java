package BusinessLogic.Validators;

public class BloodDriveValidator extends Validator {

	/**
	 * Validates role of a user before releasing blood drive information
	 */
	public void validatePermissions() { 
		// TODO Auto-generated method
	 }

	/**
	 * Validates the identity of a requester
	 */
	public void validateRequired() { 
		// TODO Auto-generated method
	 } 

}
