package BusinessLogic.Validators;

public class HospitalValidator extends Validator {

	/**
	 * Validates role of a user before releasing hospital information
	 */
	public void validatePermissions() { 
		// TODO Auto-generated method
	 }

	/**
	 * Validates the identity of a requester
	 */
	public void validateRequired() { 
		// TODO Auto-generated method
	 } 

}
