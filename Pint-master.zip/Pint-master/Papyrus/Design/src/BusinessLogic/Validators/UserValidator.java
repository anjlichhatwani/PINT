package BusinessLogic.Validators;

public class UserValidator extends Validator {

	/**
	 * Validates role of a requester before releasing user information
	 */
	public void validatePermissions() { 
		// TODO Auto-generated method
	 }

	/**
	 * Validates the identity of a requester
	 */
	public void validateRequired() { 
		// TODO Auto-generated method
	 } 

}
