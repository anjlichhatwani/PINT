package BusinessLogic.Validators;

public class NotificationValidator extends Validator {

	/**
	 * Validates role of a user before releasing notification information
	 */
	public void validatePermissions() { 
		// TODO Auto-generated method
	 }

	/**
	 * Validates the identity of a requester
	 */
	public void validateRequired() { 
		// TODO Auto-generated method
	 } 

}
