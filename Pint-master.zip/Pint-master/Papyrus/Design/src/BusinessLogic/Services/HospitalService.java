package BusinessLogic.Services;

import BusinessLogic.Validators.Validator;

public class HospitalService {

	/**
	 * 
	 */
	public Validator validator;

	/**
	 * Getter of validator
	 */
	public Validator getValidator() {
	 	 return validator; 
	}

	/**
	 * Setter of validator
	 */
	public void setValidator(Validator validator) { 
		 this.validator = validator; 
	}

	/**
	 * Fetches all the hospitals in the application
	 */
	public void getHospitals() { 
		// TODO Auto-generated method
	 } 

}
